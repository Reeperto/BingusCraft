# BingusCraft

BingusCraft is a resource pack used on a privately hosted MC server of mine. It uses github actions to provide a constantly updated release archive that the server can dish out to users.
